CREATE DATABASE IF NOT EXISTS smart_services_delivery;
CREATE TABLE citizens (
citizen_id INTEGER PRIMARY KEY AUTO_INCREMENT, 
id_number TEXT UNIQUE NOT NULL,
full_name TEXT NOT NULL,
phone TEXT,
language TEXT DEFAULT 'Enlish',
address TEXT,
village TEXT,
municipality TEXT,
created_at DATETIME DEFAULT CURRENT_TIMESTAMP
);
CREATE TABLE services (
service_id INTEGER PRIMARY KEY AUTO_INCREMENT,
service_name TEXT NOT NULL,
department TEXT,
description TEXT,
required_documents TEXT
);
CREATE TABLE community_hubs (
hub_id INTEGER PRIMARY KEY AUTO_INCREMENT,
hub_name TEXT NOT NULL,
location TEXT,
municipality TEXT,
has_solar INTEGER DEFAULT 1,
responsinle_person TEXT
);
CREATE TABLE applications (
application_id INTEGER PRIMARY KEY AUTO_INCREMENT,
citizen_id INTEGER NOT NULL,
service_id INTEGER NOT NULL,
hub_id INTEGER,
application_data TEXT,
status TEXT DEFAULT 'pending',
reference_number TEXT UNIQUE,
submitted_offline_at DATETIME DEFAULT CURRENT_TIMESTAMP,
synced_at DATETIME,
government_response TEXT,
FOREIGN KEY (citizen_id) REFERENCES citizens(citizen_id),
FOREIGN KEY (service_id) REFERENCES services(service_id),
FOREIGN KEY (hub_id) REFERENCES community_hubs(hub_id)
);
CREATE TABLE documents (
document_id INTEGER PRIMARY KEY AUTO_INCREMENT,
application_id INTEGER NOT NULL,
document_type TEXT,
file_path TEXT,
uploaded_at DATETIME DEFAULT CURRENT_TIMESTAMP,
FOREIGN KEY (application_id) REFERENCES applications(application_id)
);
CREATE TABLE sync_log (
log_id INTEGER PRIMARY KEY AUTO_INCREMENT,
sync_time DATETIME DEFAULT CURRENT_TIMESTAMP,
applications_sent INTEGER,
status TEXT,
notes TEXT
);
INSERT INTO services (service_name, department, description, required_documents) VALUES
('SASSA Grant Application', 'SASSA', 'Apply for social grants', 'ID,Proof of Residence'),
('ID Book Application', 'Home Affairs', 'Apply for a new ID book', 'Birth Certificate,2 Photos'),
('Birth Certificate', 'Home Affairs', 'Register a birth', 'Parents ID,Clinic Card');
INSERT INTO community_hubs (hub_name, location, municipality, responsible_person) VALUES
('Moletjie Community Hall', 'Moletjie Village', 'Polokwane', 'Mr. Nkosi'),
('Sebayeng Clinic Kiosks', 'Sebayeng', 'Polokwane', 'Sister Dlamini');